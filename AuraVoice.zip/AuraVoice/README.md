# Aura Voice

Your own voice assistant for Android. Say **"Aura, open YouTube"**, **"Aura, call Mom"**, **"Aura, scroll down"**, etc.

## Run it

1. Install **Android Studio** and open the `AuraVoice` folder (let it sync Gradle).
2. On your phone: Settings > About phone > tap *Build number* 7 times > enable **USB debugging** (Developer options).
3. Plug in the phone, press the green **Run** button.
4. In the app, tap the buttons in order:
   1. **Grant permissions** (mic, phone, contacts)
   2. **Turn on Aura accessibility** (find "Aura Voice" and switch it on) - this is what lets Aura scroll, tap and close apps
   3. **Allow display over other apps** - lets Aura open apps while it runs in the background
5. Tap **Start listening**, then say "Aura, ..." + a command (full list is on the app screen).

## No Android Studio? Build the APK online (free)

1. Make a free GitHub account, create a new repository.
2. On a computer, open the repo in the browser > **Add file > Upload files** and drag in everything inside the `AuraVoice` folder (including the hidden `.github` folder).
3. Open the **Actions** tab > **Build APK** > wait ~5 minutes for the green tick.
4. Open that run, download **AuraVoice-APK** (a zip), unzip it, and send `app-debug.apk` to your phone.

## Install on a Vivo phone

1. Open `app-debug.apk` from Files. Allow **Install unknown apps** when asked, and tap **Install anyway** on any security-scan screen.
2. Open Aura Voice and finish the 3 setup buttons.
3. **Vivo extras (important):**
   - Settings > Apps > Aura Voice > Permissions > **Display pop-up windows while running in the background** > Allow (otherwise "open app" can fail).
   - Settings > Battery > Background power consumption management > Aura Voice > **Allow**.
   - If the accessibility switch is greyed out (Android 13+): Settings > Apps > Aura Voice > top-right ⋮ > **Allow restricted settings**.

## Files

| File | What it does |
|---|---|
| `VoiceService.kt` | Listens all the time, catches the wake word "Aura", speaks replies. Tweak `AuraConfig` at the top. |
| `CommandHandler.kt` | Turns your sentence into an action. **Add new commands here.** |
| `AuraAccessibilityService.kt` | Scroll, swipe, tap text, back/home/recents, close current app. |
| `MainActivity.kt` | Setup screen with permission status. |

## Adding a command

In `CommandHandler.kt`, write a function that returns `true` when it handles the sentence, then add it to the `done = ...` chain in `handle()`.

## Limits (Android rules, not bugs)

- **Can't unlock your phone** by voice. Android blocks apps from bypassing the lock screen. Use Smart Lock / voice unlock in system settings for that.
- **Can't flip Wi-Fi/Bluetooth switches directly** (blocked since Android 10). Aura opens the right settings screen (a quick panel for Wi-Fi).
- **"Close app"** closes the app currently on screen, by swiping it away in Recents.
- Some phones beep each time the speech recognizer restarts. Battery optimisation on some brands (Xiaomi, Oppo, Vivo) can kill the service: set Aura to "No restrictions" in battery settings.
- Speech recognition uses Google's engine and usually needs internet.
