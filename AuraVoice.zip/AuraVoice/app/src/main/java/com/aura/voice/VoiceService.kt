package com.aura.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale

/** Easy knobs to tweak. */
object AuraConfig {
    /** Say "Aura ..." before every command. Set to false to treat everything you say as a command. */
    const val WAKE_WORD_REQUIRED = true

    /** Speech recognizers sometimes mishear the name, so a few look-alikes are accepted. */
    val WAKE_WORDS = listOf("aura", "ora", "aara", "arra")

    /** "en-IN" for Indian English, "hi-IN" for Hindi. */
    const val LANGUAGE = "en-IN"

    /** After you say just "Aura", the next sentence is a command for this long. */
    const val FOLLOW_UP_WINDOW_MS = 7000L
}

/**
 * Keeps listening in the background (as a foreground service with a notification),
 * waits for the wake word, and hands the rest of the sentence to CommandHandler.
 */
class VoiceService : Service() {

    companion object {
        const val ACTION_STOP = "com.aura.voice.STOP"
        private const val CHANNEL_ID = "aura_listening"
        private const val NOTIFICATION_ID = 1
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private lateinit var commands: CommandHandler

    private var running = false
    private var awaitCommandUntil = 0L

    @Volatile
    private var speaking = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.forLanguageTag(AuraConfig.LANGUAGE)
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { speaking = true }
            override fun onDone(utteranceId: String?) { speaking = false }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { speaking = false }
        })
        commands = CommandHandler(this) { say(it) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(),
            if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        )
        if (!running) {
            running = true
            startListening()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        tts.shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------ listening

    private fun startListening() {
        if (!running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech recognition isn't available on this phone")
            stopSelf()
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, AuraConfig.LANGUAGE)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(intent)
    }

    private fun restartSoon(delayMs: Long = 400) {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            if (!running) return@postDelayed
            if (speaking) restartSoon(500) else startListening()
        }, delayMs)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val heard = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.filter { it.isNotBlank() }
                .orEmpty()
            if (heard.isNotEmpty()) processHeard(heard)
            restartSoon()
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    say("I need microphone permission")
                    stopSelf()
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    recognizer?.cancel()
                    restartSoon(1500)
                }
                else -> restartSoon() // no match / timeout / network: just listen again
            }
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun processHeard(candidates: List<String>) {
        if (!AuraConfig.WAKE_WORD_REQUIRED) {
            commands.handle(candidates.first())
            return
        }
        val now = SystemClock.elapsedRealtime()

        // The recognizer returns a few alternatives; use the first one that contains the wake word.
        for (text in candidates) {
            val words = text.lowercase(Locale.ROOT).split(" ").filter { it.isNotBlank() }
            val idx = words.indexOfFirst { it in AuraConfig.WAKE_WORDS }
            if (idx >= 0) {
                val command = words.drop(idx + 1).joinToString(" ")
                if (command.isBlank()) {
                    awaitCommandUntil = now + AuraConfig.FOLLOW_UP_WINDOW_MS
                    say("Yes?")
                } else {
                    commands.handle(command)
                }
                return
            }
        }

        // Said just "Aura" a moment ago? Then this sentence is the command.
        if (now < awaitCommandUntil) {
            awaitCommandUntil = 0
            commands.handle(candidates.first())
        }
    }

    // --------------------------------------------------------------- speech

    private fun say(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aura-" + System.nanoTime())
    }

    // --------------------------------------------------------- notification

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Aura listening", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Aura is listening")
            .setContentText("Say \"Aura\" and then a command")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
    }
}
