package com.aura.voice

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * The "hands" of Aura. Once the user switches this service on in
 * Settings > Accessibility, it can swipe/scroll, tap things on screen,
 * and press Back / Home / Recents on their behalf.
 */
class AuraAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AuraAccessibilityService? = null

        /** Package name of the app currently on screen (ignores Aura itself and System UI). */
        @Volatile
        var currentPackage: String? = null
    }

    private val main = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg != packageName && pkg != "com.android.systemui") {
            currentPackage = pkg
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    // ---------------------------------------------------------------- actions

    /** Back, Home, Recents, Notifications, Quick Settings, Lock, Screenshot... */
    fun global(action: Int): Boolean = performGlobalAction(action)

    /** "Scroll down" = finger moves up (so you see content further down the page). */
    fun scroll(down: Boolean) {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val high = m.heightPixels * 0.30f
        val low = m.heightPixels * 0.70f
        if (down) swipe(x, low, x, high) else swipe(x, high, x, low)
    }

    fun swipeSideways(left: Boolean) {
        val m = resources.displayMetrics
        val y = m.heightPixels / 2f
        val a = m.widthPixels * 0.80f
        val b = m.widthPixels * 0.20f
        if (left) swipe(a, y, b, y) else swipe(b, y, a, y)
    }

    /** Finds on-screen text (or a content description) and taps it. */
    fun clickByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(text)
        for (node in matches) {
            var cur: AccessibilityNodeInfo? = node
            while (cur != null) {
                if (cur.isClickable) {
                    return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                cur = cur.parent
            }
        }
        return false
    }

    /**
     * Android doesn't let apps kill other apps directly, so we do what a person does:
     * open Recents, swipe the current app's card up, then return Home.
     */
    fun closeCurrentApp() {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        global(GLOBAL_ACTION_RECENTS)
        main.postDelayed({
            swipe(x, m.heightPixels * 0.55f, x, m.heightPixels * 0.05f, 200)
        }, 900)
        main.postDelayed({ global(GLOBAL_ACTION_HOME) }, 1600)
    }

    // ---------------------------------------------------------------- helpers

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 300) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
