package com.aura.voice

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date
import java.util.Locale

/**
 * The "brain": turns a spoken sentence (already stripped of the wake word)
 * into an action. To add a new command, add a function that returns true
 * when it handled the sentence, then add it to the chain in handle().
 */
class CommandHandler(
    private val appContext: Context,
    private val say: (String) -> Unit
) {

    private val a11y get() = AuraAccessibilityService.instance

    /** Starting activities through the accessibility service is the most reliable way from the background. */
    private val launcher: Context get() = a11y ?: appContext

    private val aliases = mapOf(
        "insta" to "instagram",
        "yt" to "youtube",
        "fb" to "facebook",
        "snap" to "snapchat",
        "gpay" to "google pay"
    )

    private class SettingsEntry(val keys: List<String>, val label: String, val action: String)

    private val settingsScreens = listOf(
        SettingsEntry(listOf("wifi", "wi fi"), "Wi-Fi", Settings.ACTION_WIFI_SETTINGS),
        SettingsEntry(listOf("bluetooth"), "Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS),
        SettingsEntry(listOf("airplane", "flight mode"), "airplane mode", Settings.ACTION_AIRPLANE_MODE_SETTINGS),
        SettingsEntry(listOf("mobile data", "network", "sim"), "network", Settings.ACTION_WIRELESS_SETTINGS),
        SettingsEntry(listOf("display", "brightness", "screen timeout"), "display", Settings.ACTION_DISPLAY_SETTINGS),
        SettingsEntry(listOf("sound", "ringtone"), "sound", Settings.ACTION_SOUND_SETTINGS),
        SettingsEntry(listOf("battery"), "battery", Settings.ACTION_BATTERY_SAVER_SETTINGS),
        SettingsEntry(listOf("location", "gps"), "location", Settings.ACTION_LOCATION_SOURCE_SETTINGS),
        SettingsEntry(listOf("storage"), "storage", Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
        SettingsEntry(listOf("apps", "application"), "apps", Settings.ACTION_APPLICATION_SETTINGS),
        SettingsEntry(listOf("accessibility"), "accessibility", Settings.ACTION_ACCESSIBILITY_SETTINGS),
        SettingsEntry(listOf("date", "time zone"), "date and time", Settings.ACTION_DATE_SETTINGS),
        SettingsEntry(listOf("language"), "language", Settings.ACTION_LOCALE_SETTINGS),
        SettingsEntry(listOf("security"), "security", Settings.ACTION_SECURITY_SETTINGS),
        SettingsEntry(listOf("nfc"), "NFC", Settings.ACTION_NFC_SETTINGS),
        SettingsEntry(listOf("vpn"), "VPN", Settings.ACTION_VPN_SETTINGS),
        SettingsEntry(listOf("developer options"), "developer options", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
        SettingsEntry(listOf("about phone"), "about phone", Settings.ACTION_DEVICE_INFO_SETTINGS),
        SettingsEntry(listOf("settings", "setting"), "phone", Settings.ACTION_SETTINGS)
    )

    // ------------------------------------------------------------ entry point

    fun handle(raw: String) {
        val cmd = normalize(raw)
        if (cmd.isEmpty()) return

        val done = gestures(cmd) ||
            systemButtons(cmd) ||
            audioAndTorch(cmd) ||
            info(cmd) ||
            calling(cmd) ||
            searching(cmd) ||
            tapping(cmd) ||
            closing(cmd) ||
            settings(cmd) ||
            opening(cmd)

        if (!done) say("Sorry, I didn't understand $cmd")
    }

    // ------------------------------------------------------------- commands

    private fun gestures(cmd: String): Boolean {
        when (cmd) {
            in setOf("scroll down", "swipe up", "scroll neeche") -> withA11y { it.scroll(down = true) }
            in setOf("scroll up", "swipe down", "scroll upar") -> withA11y { it.scroll(down = false) }
            "swipe left" -> withA11y { it.swipeSideways(left = true) }
            "swipe right" -> withA11y { it.swipeSideways(left = false) }
            else -> return false
        }
        return true
    }

    private fun systemButtons(cmd: String): Boolean {
        val action: Int? = when (cmd) {
            in setOf("back", "go back", "peeche jao") -> AccessibilityService.GLOBAL_ACTION_BACK
            in setOf("home", "go home", "home screen", "go to home") -> AccessibilityService.GLOBAL_ACTION_HOME
            in setOf("recent apps", "recents", "show recent apps") -> AccessibilityService.GLOBAL_ACTION_RECENTS
            in setOf("notifications", "show notifications", "notification panel") ->
                AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            in setOf("quick settings", "open quick settings") -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            "power menu" -> AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
            in setOf("lock", "lock phone", "lock screen", "lock the phone") ->
                if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN else null
            in setOf("screenshot", "take screenshot", "take a screenshot") ->
                if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT else null
            else -> return false
        }
        if (action == null) {
            say("That needs a newer version of Android")
            return true
        }
        withA11y { it.global(action) }
        return true
    }

    private fun audioAndTorch(cmd: String): Boolean {
        when {
            cmd in setOf("volume up", "increase volume", "turn volume up", "louder") ->
                adjustVolume(AudioManager.ADJUST_RAISE)
            cmd in setOf("volume down", "decrease volume", "turn volume down", "lower volume", "quieter") ->
                adjustVolume(AudioManager.ADJUST_LOWER)
            cmd in setOf("mute", "silent", "mute phone") -> adjustVolume(AudioManager.ADJUST_MUTE)
            cmd in setOf("unmute", "unmute phone") -> adjustVolume(AudioManager.ADJUST_UNMUTE)
            cmd in setOf("max volume", "full volume") -> maxVolume()
            cmd.hasWord("flashlight") || cmd.hasWord("torch") -> flashlight(on = !cmd.hasWord("off"))
            else -> return false
        }
        return true
    }

    private fun info(cmd: String): Boolean {
        val asking = cmd.startsWith("what") || cmd.startsWith("tell")
        when {
            asking && cmd.hasWord("time") ->
                say("It is " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date()))
            asking && cmd.hasWord("date") ->
                say("Today is " + DateFormat.getDateInstance(DateFormat.FULL).format(Date()))
            else -> return false
        }
        return true
    }

    private fun calling(cmd: String): Boolean {
        val target = (after(cmd, "call", "phone", "dial")
            ?: before(cmd, "ko call karo", "ko call kar do", "ko phone karo", "ko call"))
            ?.removePrefix("my ")?.trim() ?: return false

        if (target.isBlank()) {
            say("Who should I call?")
            return true
        }
        if (!granted(Manifest.permission.CALL_PHONE)) {
            say("I need phone permission. Open the Aura app to allow it.")
            return true
        }
        val digits = target.replace(" ", "")
        val number = if (digits.matches(Regex("\\+?\\d{3,15}"))) digits else lookupContact(target)
        if (number == null) {
            say("I couldn't find $target in your contacts")
            return true
        }
        say("Calling $target")
        startSafely(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
        return true
    }

    private fun searching(cmd: String): Boolean {
        val query = after(cmd, "search for", "search", "google", "look up")
            ?: before(cmd, "search karo", "search kar") ?: return false
        say("Searching for $query")
        startSafely(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query))
        return true
    }

    private fun tapping(cmd: String): Boolean {
        val label = after(cmd, "click on", "tap on", "click", "tap", "press") ?: return false
        withA11y { s ->
            if (!s.clickByText(label)) say("I can't see $label on the screen")
        }
        return true
    }

    private fun closing(cmd: String): Boolean {
        val target = if (cmd in setOf("close", "close app", "close this app", "close the app", "exit app", "band karo")) {
            ""
        } else {
            after(cmd, "close", "exit", "quit") ?: before(cmd, "band karo", "band kar do") ?: return false
        }
        val service = a11y
        if (service == null) {
            say("Please turn on the Aura accessibility service first")
            return true
        }
        val named = target.removePrefix("the ").removeSuffix(" app").trim()
        if (named.isNotBlank() && named != "this") {
            val current = currentAppLabel()
            if (current == null || !(current.contains(named) || named.contains(current))) {
                say("$named isn't the app on screen")
                return true
            }
        }
        say("Closing app")
        service.closeCurrentApp()
        return true
    }

    private fun settings(cmd: String): Boolean {
        val entry = settingsScreens.firstOrNull { e -> e.keys.any { cmd.hasWord(it) } } ?: return false
        say("Opening ${entry.label} settings")
        // Wi-Fi gets the quick pop-up panel (with the on/off switch) on Android 10+
        val action = if (entry.action == Settings.ACTION_WIFI_SETTINGS && Build.VERSION.SDK_INT >= 29) {
            Settings.Panel.ACTION_INTERNET_CONNECTIVITY
        } else {
            entry.action
        }
        startSafely(Intent(action))
        return true
    }

    private fun opening(cmd: String): Boolean {
        val target = after(cmd, "open", "launch", "start", "run")
            ?: before(cmd, "kholo", "khol do", "open karo", "chalu karo", "start karo") ?: return false
        if (target.isBlank()) return false

        val name = aliases[target] ?: target
        val pkg = findApp(name)
        if (pkg == null) {
            say("I couldn't find an app called $target")
            return true
        }
        val launch = appContext.packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) {
            say("I couldn't open $target")
            return true
        }
        say("Opening $target")
        startSafely(launch)
        return true
    }

    // -------------------------------------------------------------- helpers

    private fun normalize(raw: String): String {
        var s = raw.lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9+ ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        for (filler in listOf("hey ", "ok ", "please ", "can you ", "could you ", "will you ")) {
            if (s.startsWith(filler)) s = s.removePrefix(filler)
        }
        return s.removeSuffix(" please").trim()
    }

    private fun String.hasWord(w: String) = " $this ".contains(" $w ")

    private fun after(cmd: String, vararg prefixes: String): String? {
        for (p in prefixes) if (cmd.startsWith("$p ")) return cmd.removePrefix("$p ").trim()
        return null
    }

    private fun before(cmd: String, vararg suffixes: String): String? {
        for (s in suffixes) if (cmd.endsWith(" $s")) return cmd.removeSuffix(" $s").trim()
        return null
    }

    private fun withA11y(block: (AuraAccessibilityService) -> Unit) {
        val s = a11y
        if (s == null) say("Please turn on the Aura accessibility service first") else block(s)
    }

    private fun granted(permission: String) =
        ContextCompat.checkSelfPermission(appContext, permission) == PackageManager.PERMISSION_GRANTED

    private fun startSafely(intent: Intent) {
        try {
            launcher.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            say("Sorry, I couldn't do that")
        }
    }

    /** Best matching launcher app for a spoken name. Returns its package name. */
    private fun findApp(name: String): String? {
        val pm = appContext.packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val candidates = pm.queryIntentActivities(launchIntent, 0).mapNotNull { info ->
            val label = info.loadLabel(pm).toString().lowercase(Locale.ROOT)
                .replace(Regex("[^a-z0-9 ]"), "").trim()
            val score = when {
                label == name -> 4
                label.startsWith(name) -> 3
                label.contains(name) -> 2
                label.length >= 3 && name.contains(label) -> 1
                else -> 0
            }
            if (score > 0) Triple(info.activityInfo.packageName, label, score) else null
        }
        return candidates
            .maxWithOrNull(compareBy<Triple<String, String, Int>>({ it.third }, { -it.second.length }))
            ?.first
    }

    private fun currentAppLabel(): String? {
        val pkg = AuraAccessibilityService.currentPackage ?: return null
        return try {
            val pm = appContext.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString().lowercase(Locale.ROOT)
        } catch (e: Exception) {
            null
        }
    }

    private fun lookupContact(name: String): String? {
        if (!granted(Manifest.permission.READ_CONTACTS)) return null
        return try {
            appContext.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"),
                null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    private fun adjustVolume(direction: Int) {
        val am = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }

    private fun maxVolume() {
        val am = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
            AudioManager.FLAG_SHOW_UI
        )
    }

    private fun flashlight(on: Boolean) {
        try {
            val cm = appContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                say("I couldn't find a flashlight")
                return
            }
            cm.setTorchMode(id, on)
            say(if (on) "Flashlight on" else "Flashlight off")
        } catch (e: Exception) {
            say("I couldn't control the flashlight")
        }
    }
}
