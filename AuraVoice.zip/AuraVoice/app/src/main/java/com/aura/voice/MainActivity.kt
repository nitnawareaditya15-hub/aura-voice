package com.aura.voice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.btnPermissions).setOnClickListener {
            val perms = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS
            )
            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
            permissionLauncher.launch(perms.toTypedArray())
        }

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find \"Aura Voice\" and turn it on", Toast.LENGTH_LONG).show()
        }

        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!granted(Manifest.permission.RECORD_AUDIO)) {
                Toast.makeText(this, "Grant permissions first", Toast.LENGTH_SHORT).show()
            } else {
                ContextCompat.startForegroundService(this, Intent(this, VoiceService::class.java))
                Toast.makeText(this, "Aura is listening. Say \"Aura\" + a command", Toast.LENGTH_LONG).show()
            }
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, VoiceService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun mark(ok: Boolean) = if (ok) "✅" else "⬜"

    private fun refresh() {
        status.text = buildString {
            appendLine("${mark(granted(Manifest.permission.RECORD_AUDIO))}  Microphone")
            appendLine("${mark(granted(Manifest.permission.CALL_PHONE))}  Phone calls")
            appendLine("${mark(granted(Manifest.permission.READ_CONTACTS))}  Contacts")
            appendLine("${mark(AuraAccessibilityService.instance != null)}  Accessibility service")
            append("${mark(Settings.canDrawOverlays(this@MainActivity))}  Display over other apps")
        }
    }
}
